﻿using System;
using System.Net;
using System.Web.Http;
using refactor_me.Models;
using System.Collections.Generic;
using refactor_me.Entities;

namespace refactor_me.Controllers
{
    [RoutePrefix("products")]
    public class ProductsController : ApiController
    {
        private IProductRepository _productRepository = new ProductRepository();
        [Route("")]
        [HttpGet]
        public IEnumerable<Product> GetAll()
        {
            return _productRepository.GetProducts();
        }

        [Route("{name}")]
        [HttpGet]
        public IEnumerable<Product> SearchByName(string name)
        {
            return _productRepository.GetProducts(name);
        }

        [Route("{id:Guid}")]
        [HttpGet]
        public Product GetProduct(Guid id)
        {
            var product = _productRepository.GetProduct(id);
            if (product == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);
            return product;
        }

        [Route("")]
        [HttpPost]
        public void Create(Product product)
        {
            _productRepository.SaveProduct(product);
        }

        [Route("{id:Guid}")]
        [HttpPut]
        public void Update(Guid id, Product product)
        {
            _productRepository.SaveProduct(product);
        }

        [Route("{id:Guid}")]
        [HttpDelete]
        public void Delete(Guid id)
        {
            _productRepository.DeleteProduct(id);
        }

        [Route("{productId}/options")]
        [HttpGet]
        public IEnumerable<ProductOption> GetOptions(Guid productId)
        {
            return _productRepository.GetProductOptions(productId);
        }

        [Route("{productId}/options/{id}")]
        [HttpGet]
        public ProductOption GetOption(Guid id)
        {
            var option = _productRepository.GetProductOption(id);
            if (option == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            return option;
        }

        [Route("{productId:Guid}/options")]
        [HttpPost]
        public void CreateOption(Guid productId, ProductOption option)
        {
            option.ProductId = productId;
            _productRepository.SaveProductOption(option);
        }

        [Route("{productId}/options/{id}")]
        [HttpPut]
        public void UpdateOption(Guid id, ProductOption option)
        {
            option.Id = id;
            _productRepository.SaveProductOption(option);
        }

        [Route("{productId}/options/{id}")]
        [HttpDelete]
        public void DeleteOption(Guid id)
        {
            _productRepository.DeleteProductOption(id);
        }
    }
}
