﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace refactor_me.Helpers
{
    public static class DBUtilities
    {
        public static string ToNullableString(object value)
        {
            return value == DBNull.Value ? string.Empty : value.ToString();
        }
        public static decimal ToDecimal(object value)
        {
            return Convert.ToDecimal(value.ToString());
        }
    }
}