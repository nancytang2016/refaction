﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using refactor_me.Entities;
using refactor_me.Helpers;
using System.Data.SqlClient;

namespace refactor_me.Data
{
    public class DataAccess
    {
        public IEnumerable<Product> GetProducts()
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                string query = "select * from product";

                List <Product> products = new List<Product>();

                using (var command = connection.CreateCommand(query))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            products.Add(new Product()
                            {
                                Id = new Guid(reader["Id"].ToString()),
                                Name = reader["Name"].ToString(),
                                Description = DBUtilities.ToNullableString(reader["Description"]),
                                Price = DBUtilities.ToDecimal(reader["Price"]),
                                DeliveryPrice = DBUtilities.ToDecimal(reader["DeliveryPrice"])
                            });

                        }
                    }
                }
                return products;
            }
        }

        public IEnumerable<Product> GetProducts(string name)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                string query = String.Format("select * from product where lower(name) like '%{0}%'", name.ToLower());

                List<Product> products = new List<Product>();

                using (var command = connection.CreateCommand(query))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            products.Add(new Product()
                            {
                                Id = new Guid(reader["Id"].ToString()),
                                Name = reader["Name"].ToString(),
                                Description = DBUtilities.ToNullableString(reader["Description"]),
                                Price = DBUtilities.ToDecimal(reader["Price"]),
                                DeliveryPrice = DBUtilities.ToDecimal(reader["DeliveryPrice"])
                            });

                        }
                    }
                }

                return products;
            }
        }

        public Product GetProduct(Guid id)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                string query = String.Format("select * from product where id = '{0}'", id);

                Product product = null;

                using (var command = connection.CreateCommand(query))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            product = new Product()
                            {
                                Id = new Guid(reader["Id"].ToString()),
                                Name = reader["Name"].ToString(),
                                Description = DBUtilities.ToNullableString(reader["Description"]),
                                Price = DBUtilities.ToDecimal(reader["Price"]),
                                DeliveryPrice = DBUtilities.ToDecimal(reader["DeliveryPrice"])
                            };

                        }
                    }
                }
                return product;
            }
        }

        public void DeleteProduct(Guid id)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                string query = String.Format("delete * from product where id = '{0}'", id);

                connection.ExecuteCommand(query);
            }
        }

        public void SaveProduct(Product product)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                var cmd = product.IsNew ?
                     String.Format("insert into product (id, name, description, price, deliveryprice) values ('{0}', '{1}', '{2}', {3}, {4})"
                     , product.Id, product.Name, product.Description, product.Price, product.DeliveryPrice) :
                     String.Format("update product set name = '{0}', description = '{1}', price = {2}, deliveryprice = {3} where id = '{4}'"
                     , product.Name, product.Description, product.Price, product.DeliveryPrice, product.Id);

                connection.ExecuteCommand(cmd);
            }
        }

        public IEnumerable<ProductOption> GetProductOptions(Guid productId)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                string query = String.Format("select * from productoption where productid = '{0}' ", productId.ToString());

                List<ProductOption> productOptions = new List<ProductOption>();

                using (var command = connection.CreateCommand(query))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            productOptions.Add(new ProductOption()
                            {
                                Id = new Guid(reader["Id"].ToString()),
                                Name = reader["Name"].ToString(),
                                Description = DBUtilities.ToNullableString(reader["Description"]),
                                ProductId = productId
                            });

                        }
                    }
                }
                return productOptions;
            }
        }

        public ProductOption GetProductOption(Guid productOptionId)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                string query = String.Format("select * from productoption where id = '{0}'", productOptionId);

                ProductOption productOption = null;

                using (var command = connection.CreateCommand(query))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            productOption = new ProductOption()
                            {
                                Id = new Guid(reader["Id"].ToString()),
                                Name = reader["Name"].ToString(),
                                Description = DBUtilities.ToNullableString(reader["Description"]),
                                ProductId = new Guid(reader["ProductId"].ToString())
                            };

                        }
                    }
                }
                return productOption;
            }
        }

        public void SaveProductOption(ProductOption productOption)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                var cmd = productOption.IsNew ?
                     String.Format("insert into productoption (id, productid, name, description) values ('{Id}', '{ProductId}', '{Name}', '{Description}') values ('{0}', '{1}', '{2}', '{3}')"
                     , productOption.Id, productOption.Name, productOption.Description, productOption.ProductId) :
                     String.Format("update productoption set name = '{0}', description = '{1}' where id = '{2}'"
                     , productOption.Name, productOption.Description, productOption.Id);

                connection.ExecuteCommand(cmd);
            }
        }

        public void DeleteProductOption(Guid id)
        {
            using (var connection = new ProductConnection())
            {
                connection.Open();

                string query = String.Format("delete from productoption where id = '{0}'", id.ToString());

                connection.ExecuteCommand(query);
            }
        }
    }
}
