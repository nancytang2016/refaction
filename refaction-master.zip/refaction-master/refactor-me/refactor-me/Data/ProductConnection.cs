﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace refactor_me.Data
{
    public class ProductConnection : IDisposable
    {
        SqlConnection _connection;

        public void Open()
        {
            if (_connection == null)
            {
                _connection = GetConnection();
            }

            if (_connection.State != ConnectionState.Open)
            {
                _connection.Open(); 
            }
        }

        public void Close()
        {
            if (_connection != null && _connection.State == System.Data.ConnectionState.Open)
            {
                _connection.Close();
            }
        }
        public void ExecuteCommand(string command)
        {
            using (SqlCommand cmd = new SqlCommand(command, _connection))
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 30;
                cmd.ExecuteNonQuery();
            }
        }

        public SqlCommand CreateCommand(string query)
        {
            SqlCommand command = new SqlCommand(query, _connection);

            return command;
        }

        public static string GetConnectionString()
        {
            string databsePath = HttpRuntime.AppDomainAppPath + "\\App_Data";
            //This line does not work
            AppDomain.CurrentDomain.SetData("DataDirectory", databsePath);
            var connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            return connectionString.Replace("{DataDirectory}", databsePath);

        }

        private static SqlConnection GetConnection()
        {

            string connString = GetConnectionString();
            if (string.IsNullOrWhiteSpace(connString))
            {
                throw new Exception("Unable to obtain connection string");
            }

            SqlConnection connection = new SqlConnection(connString);
            return connection;

        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing && _connection != null)
            {
                Close();
                _connection.Dispose();
            }
        }
    }
}