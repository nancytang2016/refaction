﻿using refactor_me.Data;
using refactor_me.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace refactor_me.Models
{
    public class ProductRepository : IProductRepository
    {
        private DataAccess _dataProcess;

        public DataAccess DataProcess
        {
            get
            {
                if (_dataProcess == null)
                {
                    _dataProcess = new DataAccess();
                }
                return _dataProcess;
            }
        }
        public IEnumerable<Product> GetProducts()
        {
            return DataProcess.GetProducts();
        }

        public IEnumerable<Product> GetProducts(string name)
        {
            return DataProcess.GetProducts(name);
        }
        public Product GetProduct(Guid id)
        {
            return DataProcess.GetProduct(id);
        }
        public void DeleteProduct(Guid id)
        {
            DataProcess.DeleteProduct(id);
        }
        public void SaveProduct(Product product)
        {
            DataProcess.SaveProduct(product);
        }
        public IEnumerable<ProductOption> GetProductOptions(Guid productId)
        {
            return DataProcess.GetProductOptions(productId);
        }
        public ProductOption GetProductOption(Guid productOptionId)
        {
            return DataProcess.GetProductOption(productOptionId);
        }
        public void DeleteProductOption(Guid productOptionId)
        {
            DataProcess.DeleteProductOption(productOptionId);
        }
        public void SaveProductOption(ProductOption productOption)
        {
            DataProcess.SaveProductOption(productOption);
        }
    }
}