﻿using refactor_me.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace refactor_me.Models
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetProducts();
        IEnumerable<Product> GetProducts(string name);
        Product GetProduct(Guid id);
        void DeleteProduct(Guid id);
        void SaveProduct(Product product);
        IEnumerable<ProductOption> GetProductOptions(Guid productId);
        ProductOption GetProductOption(Guid productOptionId);
        void DeleteProductOption(Guid productOptionId);
        void SaveProductOption(ProductOption productOption);
    }
}